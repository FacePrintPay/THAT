export default function handler(req, res) {
  res.status(200).json({ message: "✅ /api/comand is live. Your agent loop is ready." });
}
