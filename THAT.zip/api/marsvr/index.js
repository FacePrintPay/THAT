export default function handler(req, res) {
  res.status(200).json({ message: "🪐 MarsVR module connected. Welcome to Jezero Crater." });
}
