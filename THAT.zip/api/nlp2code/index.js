export default function handler(req, res) {
  res.status(200).json({ message: "💬 NLP2Code is online. Ready to convert prompt to code." });
}
