export default function handler(req, res) {
  res.status(200).json({ status: "Listening for audio prompts...", commandMode: "whisper-trigger" });
}
