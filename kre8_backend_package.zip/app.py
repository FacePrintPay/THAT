from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Kre8 backend running successfully"}