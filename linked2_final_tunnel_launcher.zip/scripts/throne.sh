#!/bin/bash
echo "🧬 Initializing Linked2 Tunnel Launcher..."
git clone https://github.com/FacePrintPay/VeRseD_Ai.git
cd VeRseD_Ai
npm install
npx vercel --prod
echo "✅ Verse deployed via Linked2 Tunnel"
